import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Coupon } from './coupons';

@Injectable({
  providedIn: 'root',
})
export class CentraliseddbService {
  localStorage: Storage;

  constructor() {}

  getCoupon(couponID) {
    var retrievedObject = localStorage.getItem(couponID);
    console.log('retrievedObject: ', JSON.parse(retrievedObject));
  }

  addCoupon(coupon) : string {
    var couponID = "C" + Math.random() + Math.random() * 100000
    localStorage.setItem(couponID, JSON.stringify(couponID));
    return couponID;
  }

  clearOne(couponID) {
    localStorage.removeItem(couponID);
  } 

  getCouponList() {
    console.log(localStorage);
  }

  clearAll() {
    localStorage.clear();
  } 

}
