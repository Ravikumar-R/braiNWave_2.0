export interface Coupon {
    type: string;
    validity: string;
    recipientPhone: number;
    recipientName: string;
    couponID: string
}
